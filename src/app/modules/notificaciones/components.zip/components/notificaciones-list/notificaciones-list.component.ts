import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { Notificacion } from '../../../../models/notificacion.model';
import { NotificacionesService } from '../../../../services/notificaciones.service';
import { AuthService } from '../../../../services/auth.service'; // ✅ Importamos el AuthService también

@Component({
  selector: 'app-notificaciones-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule
  ],
  templateUrl: './notificaciones-list.component.html',
  styleUrls: ['./notificaciones-list.component.scss']
})
export class NotificacionesListComponent implements OnInit {

  notificaciones: Notificacion[] = [];
  filteredNotificaciones: Notificacion[] = [];

  perfilUsuario: 'corporativo' | 'masivo' = 'masivo'; // Default a masivo por seguridad

  constructor(
    private notificacionesService: NotificacionesService,
    private authService: AuthService // ✅ Inyectamos el AuthService
  ) {}

  ngOnInit(): void {
    // 🔵 Obtenemos el perfil real del usuario logueado
    const rol = this.authService.getRol();

    // Solo si el rol es válido
    if (rol === 'corporativo' || rol === 'masivo') {
      this.perfilUsuario = rol;
    }

    this.notificacionesService.getNotificaciones().subscribe((data) => {
      this.notificaciones = data;
      this.filteredNotificaciones = this.notificaciones.filter(n => n.perfil === this.perfilUsuario);
    });
  }
}
